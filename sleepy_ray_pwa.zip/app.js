// Sleepy Ray - Atmospheric Alarm Logic

let wakeLock = null;
let alarmTimeStr = null;
let isAlarmSet = false;
let alarmTimeout = null;

const clockEl = document.getElementById('clock').querySelector('.time');
const secondsEl = document.getElementById('clock').querySelector('.seconds');
const toggleBtn = document.getElementById('toggleAlarm');
const stopBtn = document.getElementById('stopAlarm');
const alarmInput = document.getElementById('alarmTime');
const statusLine = document.getElementById('statusLine');
const overlay = document.getElementById('alarmOverlay');
const audio = document.getElementById('alarmAudio');

// Update Clock
function updateClock() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getHours() < 24 ? now.getMinutes() : 0).padStart(2, '0'); // Fix for minute display
    const s = String(now.getSeconds()).padStart(2, '0');
    
    // Actually, just standard date formatting
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    clockEl.textContent = timeStr;
    secondsEl.textContent = s;

    // Check Alarm
    if (isAlarmSet && alarmTimeStr === timeStr && s === "00") {
        triggerAlarm();
    }
}

setInterval(updateClock, 1000);
updateClock();

// Wake Lock API
async function requestWakeLock() {
    if ('wakeLock' in navigator) {
        try {
            wakeLock = await navigator.wakeLock.request('screen');
            console.log('Wake Lock is active');
            wakeLock.addEventListener('release', () => {
                console.log('Wake Lock was released');
            });
        } catch (err) {
            console.error(`${err.name}, ${err.message}`);
        }
    }
}

function releaseWakeLock() {
    if (wakeLock !== null) {
        wakeLock.release();
        wakeLock = null;
    }
}

// Alarm Controls
toggleBtn.addEventListener('click', async () => {
    if (!isAlarmSet) {
        // Set Alarm
        alarmTimeStr = alarmInput.value;
        if (!alarmTimeStr) return;
        
        isAlarmSet = true;
        toggleBtn.textContent = "Cancel Alarm";
        toggleBtn.style.background = "rgba(255, 255, 255, 0.1)";
        statusLine.textContent = `Alarm set for ${alarmTimeStr}`;
        
        // Browsers require interaction to play sound later, 
        // we can "warm up" the audio context if needed, but sticking to standard.
        // Also request wake lock
        await requestWakeLock();
    } else {
        // Cancel Alarm
        cancelAlarm();
    }
});

function cancelAlarm() {
    isAlarmSet = false;
    toggleBtn.textContent = "Set Alarm";
    toggleBtn.style.background = "linear-gradient(135deg, var(--color-warm-orange), var(--color-magenta))";
    statusLine.textContent = "Alarm is Off";
    releaseWakeLock();
}

function triggerAlarm() {
    overlay.style.display = 'flex';
    audio.play();
    isAlarmSet = false; // Reset after trigger
}

stopBtn.addEventListener('click', () => {
    overlay.style.display = 'none';
    audio.pause();
    audio.currentTime = 0;
    cancelAlarm();
});

// PWA Service Worker Registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').then(registration => {
            console.log('SW registered: ', registration);
        }).catch(registrationError => {
            console.log('SW registration failed: ', registrationError);
        });
    });
}
